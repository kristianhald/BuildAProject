﻿using FluentNHibernate.Mapping;

namespace DependencyUsingOldVersion
{
  public class Dependency : ClassMap<Dependency>
    {
      public void Run()
      {
      }
    }
}
