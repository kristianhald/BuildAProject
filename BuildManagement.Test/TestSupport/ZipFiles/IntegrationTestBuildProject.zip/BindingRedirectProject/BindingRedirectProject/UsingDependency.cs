﻿using DependencyUsingOldVersion;
using FluentNHibernate.Mapping;
using NUnit.Framework;

namespace BindingRedirectProject
{
  [TestFixture]
  public class UsingDependency : ClassMap<UsingDependency>
  {
    [Test]
    public void Run()
    {
      var dependency = new Dependency();
      dependency.Run();
    }
  }
}
