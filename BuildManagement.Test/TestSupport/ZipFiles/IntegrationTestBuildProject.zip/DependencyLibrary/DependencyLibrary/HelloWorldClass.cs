﻿using System;

namespace DependencyLibrary
{
  public class HelloWorldClass
  {
    public void PrintHelloWorld()
    {
      Console.WriteLine(ExternalLibrary.ExternalClass.GetString());
    }
  }
}
