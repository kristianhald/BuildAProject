﻿using DependencyLibrary;

namespace ApplicationConsole
{
  class Program
  {
    static void Main(string[] args)
    {
      // Calls external DLL
      new HelloWorldClass().PrintHelloWorld();
    }
  }
}
