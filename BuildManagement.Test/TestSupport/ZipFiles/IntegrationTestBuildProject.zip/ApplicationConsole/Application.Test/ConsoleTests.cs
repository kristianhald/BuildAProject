﻿using NUnit.Framework;

namespace Application.Test
{
  [TestFixture]
  public sealed class ConsoleTests
  {
    [Test]
    public void DoesNothing()
    {
      Assert.IsTrue(true);
    }
  }
}
