﻿
using System;

namespace CompileErrorProject
{
    public class ClassHasBuildError
    {
      public void LineIsMissingSemiColon()
      {
        Console.Write("This line is missing a semicolon and therefore failing on purpose.")
      }
    }
}
