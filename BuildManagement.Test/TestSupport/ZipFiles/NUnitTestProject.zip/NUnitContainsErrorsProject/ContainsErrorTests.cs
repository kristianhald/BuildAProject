﻿using NUnit.Framework;
using NUnitProjectUnderTest;

namespace NUnitContainsErrorsProject
{
  [TestFixture]
  public class ContainsErrorTests
  {
    [Test]
    public void MethodReturnsOne_IsExpectedToReturnTwo_ButOneIsReturned()
    {
      // Arrange
      const int expectedValue = 2;
      var noError = new ClassUnderTest();

      // Act
      var actualValue = noError.MethodReturnsOne();

      // Assert
      Assert.AreEqual(expectedValue, actualValue);
    }
  }
}
