﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("NUnitNoErrorsProject")]
[assembly: InternalsVisibleTo("NUnitContainsErrorsProject")]

namespace NUnitProjectUnderTest
{
  internal sealed class ClassUnderTest
  {
    public int MethodReturnsOne()
    {
      return 1;
    }
  }
}
