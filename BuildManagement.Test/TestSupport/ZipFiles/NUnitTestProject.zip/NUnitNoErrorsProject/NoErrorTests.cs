﻿using NUnit.Framework;
using NUnitProjectUnderTest;

namespace NUnitNoErrorsProject
{
  [TestFixture]
  public sealed class NoErrorTests
  {
    [Test]
    public void MethodReturnsOne_IsCalled_AndOneIsReturned()
    {
      // Arrange
      const int expectedValue = 1;
      var noError = new ClassUnderTest();

      // Act
      var actualValue = noError.MethodReturnsOne();

      // Assert
      Assert.AreEqual(expectedValue, actualValue);
    }

    [Test]
    public void MethodReturnsOne_IsCalled_AndDoesNotReturnTwo()
    {
      // Arrange
      const int notExpectedValue = 2;
      var noError = new ClassUnderTest();

      // Act
      var actualValue = noError.MethodReturnsOne();

      // Assert
      Assert.AreNotEqual(notExpectedValue, actualValue);
    }
  }
}
