﻿using System;
using NUnit.Framework;

namespace NUnitSetUpContainsErrorsProject
{
  [TestFixture]
  public class ContainsErrorTests
  {
    [SetUp]
    public void SetUpMethod()
    {
      throw new Exception(
        "Throws error making it possible to test if the NUnit runners handle this.",
        new Exception("With this inner exception."));
    }

    [Test]
    public void MethodNotExecuted()
    {
      
    }
  }
}
