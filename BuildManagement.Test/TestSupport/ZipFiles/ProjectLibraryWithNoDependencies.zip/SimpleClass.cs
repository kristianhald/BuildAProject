﻿using System;

namespace ProjectLibraryWithNoDependencies
{
  public class SimpleClass
  {
    public void SimpleMethod()
    {
      Console.WriteLine("Hello World.");
    }
  }
}
